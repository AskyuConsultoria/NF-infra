import data_handling
import download_from_raw
import upload_to_trusted
import os

csv_path = '~/trusted_files/out.csv'
csv_path = os.path.expanduser(csv_path)
bucket_name = 'bucket_trusted_03231053'


download_from_raw.baixar_arquivo_cru()
data_handling.limpar_arquivo()
upload_to_trusted.realizar_upload()



