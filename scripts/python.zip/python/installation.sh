sudo apt update && sudo apt upgrade -y

sudo apt install python3-pip -y

sudo apt install python3-venv

python3 -m venv amb

source amb/bin/activate

python -m pip install -r req.txt